/* ============================================================
   SWPU in the World — 校史馆双语节点地图
   所有英文定译取自《简洁版本校史馆术语库（终稿 v3.1）》
   ============================================================ */
(function () {
  'use strict';

  /* ---------- 1. 数据：7 枚图钉 ---------- */
  const NODES = [
    {
      id: 'n1958', cat: 'event', yr: '1958', flag: '🇨🇳', country: '中国 · 四川南充', countryEn: 'Nanchong, Sichuan, China',
      lat: 30.7956, lon: 106.0847, pin: { x: 516, y: 213 },
           // 手动锚点：四川南充（地图视口坐标，见 §4 说明）
      cn: '首届开学典礼：先招生，后建校',
      en: 'The First Opening Ceremony: Enrolling Students Before Building the Campus',
      cnLong: '1958 年 3 月，南充东观、广安武胜、遂宁蓬莱三口探井喷出工业油流，石油工业部部长余秋里坐镇南充指挥，打响了川中石油会战。为开发四川石油天然气资源、培养油气勘探开发急需的技术干部，国家决定成立新中国第二所石油本科高校——四川石油学院，校址就设在会战指挥部所在的南充。9 月 20 日首届新生报到，校舍借用南充市郊飞机坝的空置营房；11 月 1 日，学院在飞机坝部队营房举行首届开学典礼，自此将每年 11 月 1 日定为建校纪念日。',
      enLong: 'In March 1958, three wildcat wells at Dongguan (Nanchong), Wusheng (Guang\'an) and Penglai (Suining) blew in with commercial oil flow. Yu Qiuli, then Minister of the Ministry of Petroleum Industry, took command in Nanchong and launched the Chuanzhong Oil Campaign. To speed up the development of Sichuan\'s oil and gas resources and train the technical personnel urgently needed for oil and gas exploration and development, the state decided to found the second petroleum undergraduate institution in New China — Sichuan Petroleum Institute. The campus would be in Nanchong, where the campaign headquarters was stationed. On 20 September, the first cohort of students reported for enrollment and was temporarily housed in the disused barracks of Feijiba (Airplane Dam) on the outskirts of the city. On 1 November, the institute held its first opening ceremony in those barracks; since then, 1 November has been observed as the University\'s founding anniversary.',
      tags: ['建校', '川中石油会战', '校庆日 11月1日', '南充校区'],
      terms: ['四川石油学院', '川中石油会战', '建校纪念日（11月1日）', '首届新生／首届开学典礼', '先招生、后建校', '石油部（石油工业部）']
    },
    {
      id: 'ma', cat: 'people', yr: '1958', flag: '🇨🇳', country: '中国 · 四川南充', countryEn: 'Nanchong, Sichuan, China',
      lat: 30.7956, lon: 106.0847, pin: { x: 472, y: 226 },
      cn: '首任院长马载：从黄埔军校到飞机坝',
      en: 'Ma Zai, the First President: From the Whampoa Military Academy to Airplane Dam',
      cnLong: '马载 1925 年考入黄埔军校（四期），1926 年加入中国共产党，参加过北伐战争，后历任新疆中苏石油公司党委书记兼总经理、石油工业部基建司司长。1958 年 8 月底，他受命率 20 余名从北京石油学院等单位抽调的教师、干部和技术工人赶赴南充，统筹规划学院的创建工作；9 月，经国务院任命为四川石油学院首任院长，并兼任党委书记。他带领师生晴天劳动、雨天上课，用三周时间抢修出通往工地的大路，把一所"先招生后建校"的学校真正立在了川北大地上。',
      enLong: 'Ma Zai was admitted to the Whampoa Military Academy (4th class) in 1925 and joined the Communist Party of China in 1926. He took part in the Northern Expedition, and later served as Secretary of the Party Committee and General Manager of the Sino-Soviet Petroleum Company in Xinjiang, then as Director of the Capital Construction Department of the Ministry of Petroleum Industry. In late August 1958, he was ordered to lead a team of more than 20 teachers, cadres and technicians drawn from Beijing Petroleum Institute and other units to Nanchong to plan and prepare the new institute. In September, by State Council appointment, he became the first president of Sichuan Petroleum Institute, concurrently serving as Secretary of the Party committee. He led the students and faculty in working on sunny days and attending classes on rainy days, and in three weeks built a road to the construction site — planting the institute, which had enrolled students before building the campus, firmly in the soil of northern Sichuan.',
      tags: ['首任院长', '黄埔军校（四期）', '石油部基建司'],
      terms: ['马载', '黄埔军校（四期）', '石油部基建司', '晴天劳动雨天上课', '先招生、后建校', '川中石油会战指挥部']
    },
    {
      id: 'n1972', cat: 'people', yr: '1972', flag: '🇨🇳', country: '中国 · 四川泸州', countryEn: 'Luzhou, Sichuan, China',
      lat: 28.873, lon: 105.441,
      pin: { x: 444, y: 268 },
      cn: '罗平亚：女基井的泥浆与七千米深井',
      en: 'Luo Pingya: The Drilling Fluid of the Nuji Well and a 7,000-Metre Well',
      cnLong: '1958 年，罗平亚报考北京石油学院钻井专业，却被四川石油学院钻井专业录取。1972 年，我国第一口超深井女基井准备在四川开钻，面临且必须自行解决的核心难题是高温泥浆。学校派他进驻井队协同攻关，他在现场一待就是五年，后来提出了"利用高温改善泥浆性能"的新观点，并逐步建立起我国自己的水基钻井液理论与技术体系。1990 年至 2005 年任西南石油学院院长，1995 年当选中国工程院院士。',
      enLong: 'In 1958, Luo Pingya sat the entrance exam for the drilling programme at Beijing Petroleum Institute, but was admitted to the drilling programme at Sichuan Petroleum Institute instead. In 1972, China\'s first ultra-deep well, the Nuji Well, was being prepared for spud-in in Sichuan, and the crucial problem that had to be solved independently was high-temperature drilling fluid. The institute sent him to the drilling crew to work on the problem on site, where he stayed for five years. He later put forward the new view of "using high temperature to improve mud properties," and went on to establish China\'s own theoretical and technical system of water-based drilling fluid. He served as President of Southwest Petroleum Institute from 1990 to 2005, and was elected an academician of the Chinese Academy of Engineering in 1995.',
      tags: ['院士', '泥浆', '水基钻井液', '七千米深井'],
      terms: ['开钻', '石油钻井', '石油工程（学科名）', '钻井液（术语库未列，此处不译为 mud）', '院士', '西南石油学院', '中国石油天然气集团有限公司（中石油）']
    },
    {
      id: 'n1993', cat: 'event', yr: '1993', flag: '🇨🇳', country: '中国 · 四川南充', countryEn: 'Nanchong, Sichuan, China',
      lat: 30.7956, lon: 106.0847, pin: { x: 510, y: 240 },
      cn: '博士点的零：获得博士学位授予权',
      en: 'Zero to Doctoral Degrees: The Authority to Confer Doctoral Degrees',
      cnLong: '在罗平亚担任院长期间，学校于 1993 年获得博士学位授予权，从一个以本科教学为主的单科性工科院校，开始向高层次人才培养和科学研究基地迈进。这件事常被校史馆忽略，却是学校后来能入选"双一流"、能在 2017 年把石油与天然气工程送进一流学科建设名单的真正起点。',
      enLong: 'During Luo Pingya\'s presidency, the institute was granted the authority to confer doctoral degrees in 1993, marking its step up from a predominantly undergraduate, single-discipline engineering school toward becoming a base for high-level talent training and scientific research. The moment is easily overlooked in the University History Museum, yet it is the real starting point of the school\'s later admission to the Double First-Class Initiative and its placement of Petroleum Engineering on the list of first-class disciplines in 2017.',
      tags: ['博士学位授予权', '从单科性到高层次'],
      terms: ['博士学位授予权', '石油工程（学科名）', '多科性大学', '西南石油学院']
    },
    {
      id: 'n2002', cat: 'event', yr: '2002', flag: '🇨🇳', country: '中国 · 四川成都', countryEn: 'Chengdu, Sichuan, China',
      lat: 30.8073, lon: 104.4557, pin: { x: 438, y: 234 },
      cn: '从南充到成都：两校区，两个坐标',
      en: 'From Nanchong to Chengdu: Two Campuses, Two Sets of Coordinates',
      cnLong: '2002 年 8 月中旬，首批师生搬迁入住成都校区；11 月 1 日，学校举行成都校区启用典礼暨建校四十四周年庆祝大会。与同期许多高校"从市中心迁往远郊"不同，西南石油学院是从南充这座小城整体迁向成都，形成了成都校区、南充校区"一校两地两校区"的办学格局。2005 年 12 月，学校正式更名为西南石油大学。',
      enLong: 'In mid-August 2002, the first group of students and faculty moved into the Chengdu Campus; on 1 November, the institute held the inauguration of the Chengdu Campus together with the celebration of its 44th founding anniversary. Unlike many of its contemporaries that "moved from city centres to distant suburbs," Southwest Petroleum Institute relocated as a whole from the small city of Nanchong to Chengdu, establishing a two-campus, two-location pattern of Nanchong Campus and Chengdu Campus. In December 2005, the school was formally renamed Southwest Petroleum University (SWPU).',
      tags: ['成都校区', '南充校区', '一校两地两校区'],
      terms: ['西南石油大学', '西南石油学院', '成都校区／南充校区', '校牌']
    },
    {
      id: 'n2017', cat: 'event', yr: '2017', flag: '🇨🇳', country: '中国南海', countryEn: 'the South China Sea',
      lat: 19.2, lon: 115.5, pin: { x: 590, y: 310 },
      cn: '可燃冰：从南海神狐海域，到世界领先',
      en: 'Gas Hydrate: From the Shenhu Area of the South China Sea to World Leadership',
      cnLong: '2012 年，周守为院士提出海洋天然气水合物固态流化开采的革命性技术设想，魏纳团队据此从一张铅笔画的工艺原理图起步，历时五年建成全球首套固态流化开采大型物理模拟实验系统。2017 年 5 月，魏纳作为中海油以外唯一一个外部单位代表参加我国首次固态流化试采，在南海神狐海域试采成功，采收率高达 80.1%。这是全球首次成功实现资源量占全球 90% 以上、开发难度最大的泥质粉砂型天然气水合物的安全可控开采。',
      enLong: 'In 2012, Academician Zhou Shouwei put forward the revolutionary idea of solid-fluidized exploitation of marine natural gas hydrate. Starting from a hand-drawn process diagram, Wei Na\'s team spent five years building the world\'s first set of a large-scale physical simulation system for solid-fluidized exploitation. In May 2017, Wei Na took part in China\'s first solid-fluidized trial production as the sole external participant outside CNOOC, achieving success in the Shenhu area of the South China Sea with a recovery rate of 80.1%. It was the world\'s first successful, safe and controllable exploitation of silty clay-type natural gas hydrate, which accounts for more than 90% of the world\'s resources and is the hardest to develop.',
      tags: ['固态流化试采', '全球首套', '世界领先'],
      terms: ['天然气水合物', '海洋天然气水合物', '固态流化试采', '全球首套', '周守为', '中国海洋石油集团有限公司（中海油）', '天然气水合物流化采掘', '中国工程院院士（术语库用 academician）']
    },
    {
      id: 'n2025', cat: 'global', yr: '2025', flag: '🇮🇶', country: '伊拉克 · 巴格达', countryEn: 'Baghdad, Iraq',
      lat: 33.3152, lon: 44.3661, pin: { x: 552, y: 204 },
      cn: '在成都签约：伊拉克国家实验室的 6000 公里',
      en: 'Signed in Chengdu: 6,000 Kilometres to Iraq\'s National Laboratory',
      cnLong: '2025 年 6 月 13 日，在"一带一路"低碳技术创新合作联盟 40 余名国际专家学者见证下，伊拉克石油部、振华石油与西南石油大学三方签订"伊拉克油气与可再生能源开发国家实验室"共建协议。这是伊拉克首个与中国高校、企业联合共建的能源领域国家级实验室，从人员培训到项目攻关由校、政、企三方协同推进，筹备历时两年。同年，中国日报报道，学校联合振华石油在 2024 年开展了 8 期培训，提升了 158 名伊拉克石油部雇员的专业能力与管理水平。一枚原本钉在成都的图钉，由此跨过 6000 公里，钉到了巴格达。',
      enLong: 'On 13 June 2025, witnessed by more than 40 international experts and scholars from the Alliance of Belt and Road Low-Carbon Technology Innovation and Cooperation, the Ministry of Oil of Iraq, ZhenHua Oil, and Southwest Petroleum University signed a tripartite agreement to jointly build the Iraq National Laboratory for Oil, Gas and Renewable Energy Development. It is Iraq\'s first national energy laboratory jointly built with a Chinese university and enterprise, advanced jointly by the university, the government and the enterprise from personnel training to project research, with two years of preparation. The same year, China Daily reported that SWPU and ZhenHua Oil had run eight training programmes in 2024, upgrading the professional competence and management of 158 employees of the Ministry of Oil of Iraq. A pin originally planted in Chengdu now crosses 6,000 kilometres to Baghdad.',
      tags: ['一带一路', '校政企三方共建', '中伊能源合作'],
      terms: ['伊拉克国家实验室（全称：伊拉克油气与可再生能源开发国家实验室）', '伊拉克石油部', '振华石油', '"一带一路"', '"一带一路"低碳技术创新合作联盟', '联盟理事成员单位', '中国石油天然气集团有限公司（中石油）', '中国海洋石油集团有限公司（中海油）']
    }
  ];

  /* ---------- 2. 术语库（38 条） ---------- */
  const GLOSS = [
    { cn: '西南石油大学', en: 'Southwest Petroleum University (SWPU)' },
    { cn: '四川石油学院', en: 'Sichuan Petroleum Institute' },
    { cn: '西南石油学院', en: 'Southwest Petroleum Institute' },
    { cn: '校史馆', en: 'the University History Museum' },
    { cn: '序厅／历史厅／现代厅／荣誉厅', en: 'Prologue Hall / History Hall / Modern Era Hall / Honors Hall' },
    { cn: '飞机坝／金鱼岭／燕儿窝', en: 'Feijiba / Jinyuling / Yan\'erwo（首次出现加简短解释）' },
    { cn: '龙井湖', en: 'Longjing Lake' },
    { cn: '莫斯科石油学院', en: 'the Moscow Petroleum Institute (I. M. Gubkin)' },
    { cn: '黄埔军校（四期）', en: 'the Whampoa Military Academy (4th class)' },
    { cn: '北京石油学院', en: 'Beijing Petroleum Institute' },
    { cn: '国家博物馆', en: 'the National Museum of China' },
    { cn: '伊拉克国家实验室（全称…）', en: 'the Iraq National Laboratory for Oil, Gas and Renewable Energy Development' },
    { cn: 'Laboratory of Petroleum Research…（G3误译）', en: 'G3误译，混淆伊方签约主体', bad: '术语库禁用', tag: '禁' },
    { cn: '伊拉克石油部', en: 'the Ministry of Oil of Iraq' },
    { cn: '振华石油', en: 'ZhenHua Oil (ZhenHua Oil Co., Ltd.)' },
    { cn: '教育部', en: 'the Ministry of Education of the People\'s Republic of China (MOE)' },
    { cn: '四川省人民政府', en: 'Sichuan Provincial People\'s Government' },
    { cn: '成都市人民政府', en: 'Chengdu Municipal People\'s Government' },
    { cn: '石油部（石油工业部）', en: 'the Ministry of Petroleum Industry' },
    { cn: '中国石油天然气集团有限公司（中石油）', en: 'China National Petroleum Corporation (CNPC)' },
    { cn: 'Cooperation（拼写硬伤）', en: '拼写硬伤，不得拼作…Cooperation', bad: 'China Petroleum Cooperation', tag: '禁' },
    { cn: '中国石油化工集团有限公司（中石化）', en: 'China Petroleum & Chemical Corporation (Sinopec Group)' },
    { cn: '中国海洋石油集团有限公司（中海油）', en: 'China National Offshore Oil Corporation (CNOOC)' },
    { cn: '三牙轮钻头', en: 'tricone bit' },
    { cn: '牙轮钻头', en: 'roller cone bit' },
    { cn: '开钻', en: 'spud in' },
    { cn: 'start drilling（非术语）', en: '不得译作 start drilling', bad: 'start drilling', tag: '禁' },
    { cn: '天然气水合物', en: 'natural gas hydrate' },
    { cn: '海洋天然气水合物', en: 'marine natural gas hydrate' },
    { cn: '固态流化试采', en: 'trial production through solid fluidization' },
    { cn: '水合物开发的新方向', en: 'a new direction of hydrate exploitation' },
    { cn: '石油工程（学科名）', en: 'Petroleum Engineering' },
    { cn: '石油工业', en: 'the petroleum industry' },
    { cn: '石油钻井', en: 'petroleum drilling' },
    { cn: '川中石油会战', en: 'the Chuanzhong Oil Campaign' },
    { cn: '全球首套', en: 'the world\'s first set of' },
    { cn: '"双一流"', en: 'the Double First-Class Initiative' },
    { cn: 'Double World-class…（术语库禁用写法）', en: '不得加 in China 或写作 Double World-class', bad: 'Double World-class／Double First-rate', tag: '禁' },
    { cn: '一流学科建设高校', en: 'a first-class discipline construction university' },
    { cn: '院士', en: 'academician (of the Chinese Academy of Sciences/Engineering)' },
    { cn: '博士学位授予权', en: 'the authority to confer doctoral degrees' },
    { cn: '多科性大学', en: 'multidisciplinary university' },
    { cn: 'comprehensive university（术语库禁用）', en: '不得译作 comprehensive university', bad: 'comprehensive university', tag: '禁' },
    { cn: '建校纪念日（11月1日）', en: 'the University\'s founding anniversary (November 1)' },
    { cn: '首届新生／首届开学典礼', en: 'the first cohort of students / the first opening ceremony' },
    { cn: '先招生、后建校', en: 'enrolling students before building the campus' },
    { cn: '晴天劳动雨天上课', en: 'worked on sunny days and attended classes on rainy days' },
    { cn: '石油部基建司', en: 'the Capital Construction Department of the Ministry of Petroleum Industry' },
    { cn: '川中石油大会战指挥部', en: 'the headquarters of the Chuanzhong Oil Campaign' },
    { cn: '成都校区／南充校区', en: 'Chengdu Campus / Nanchong Campus' },
    { cn: '中石油／中石化／中海油（简称）', en: 'CNPC / Sinopec Group / CNOOC' },
    { cn: '国家博物馆', en: 'the National Museum of China' },
    { cn: '"一带一路"', en: 'the Belt and Road Initiative' },
    { cn: '"一带一路"低碳技术创新合作联盟', en: 'the Alliance of Belt and Road Low-Carbon Technology Innovation and Cooperation' },
    { cn: '联盟理事成员单位', en: 'council member organization of the alliance' }
  ];

  /* ---------- 3. i18n ---------- */
  const I18N = {
    zh: {
      kicker: '校史翻译成连接世界的节点',
      title: '七枚图钉，把校史钉在世界地图上',
      lede: '从 1958 年南充飞机坝的七百名首届新生，到 2025 年成都签约的伊拉克国家实验室，这所学校的名字一次次越过省界、国界，落在具体的经纬线上。七个节点、七张双语卡片，讲述西南石油大学如何成为世界能源版图上的一枚钉子。',
      m1: '四川石油学院在南充成立',
      m2: '中伊共建伊拉克国家实验室',
      m3: '枚图钉，覆盖 5 个国家',
      legendTitle: '七枚图钉',
      glosTitle: '术语卡 · 从术语库里长出来的译法',
      glossSub: '本页所有英文定译均取自《简洁版本校史馆术语库（终稿 v3.1）》。点击卡片可复制英文。',
      gAll: '全部 38',
      foot1: '本页面为课程作业展示用，历史事实依据西南石油大学官网、校史档案及校方公开报道整理；英文定译严格采用课程术语库终稿 v3.1。',
      foot2: '制图数据来源 Natural Earth，底图由 d3-geo 与 topojson-client 绘制。地图投影为等距圆柱投影（Plate Carrée），仅供示意，不等同于官方地图。',
      cat: { event: '校史事件', people: '人物', global: '国际合作' },
      place: '坐标',
      openCard: '打开双语卡片 →',
      copyOK: '已复制英文定译',
      noResult: '没有匹配的术语，换个关键词试试。',
      termsTitle: '本卡用到的术语库定译',
      termOk: '已复制'
    },
    en: {
      kicker: 'THE UNIVERSITY HISTORY MUSEUM, TRANSLATED INTO NODES ON A WORLD MAP',
      title: 'Seven Pins: Pinning the University’s History to a World Map',
      lede: 'From the 700 first students at Airplane Dam in Nanchong in 1958, to the Iraq National Laboratory signed in Chengdu in 2025, the name of this university has crossed provincial and national borders again and again, landing on concrete coordinates. Seven nodes, seven bilingual cards: how Southwest Petroleum University became a pin on the world’s energy map.',
      m1: 'Sichuan Petroleum Institute founded in Nanchong',
      m2: 'Iraq-China joint national laboratory',
      m3: 'pins across 5 countries',
      legendTitle: 'Seven Pins',
      glosTitle: 'Term Cards · Renderings Grown from the Glossary',
      glossSub: 'Every English rendering on this page comes from the Glossary of the University History Museum (Final v3.1). Tap a card to copy the English.',
      gAll: 'All 38',
      foot1: 'This page is a coursework deliverable. Historical facts are compiled from the SWPU official website, university archives and public reports; all English renderings strictly follow the course glossary, final v3.1.',
      foot2: 'Base-map data: Natural Earth. Rendered with d3-geo and topojson-client. Equirectangular projection, for illustration only — not an official map.',
      cat: { event: 'Event', people: 'Person', global: 'Global' },
      place: 'Coordinates',
      openCard: 'Open bilingual card →',
      copyOK: 'English rendering copied',
      noResult: 'No matching terms. Try another keyword.',
      termsTitle: 'Glossary renderings used on this card',
      termOk: 'Copied'
    }
  };
  let lang = 'zh';

  /* ---------- 4. 地图绘制 ---------- */
  const svg = document.getElementById('map');
  const VIEW = { w: 1000, h: 500 };
  const svgns = 'http://www.w3.org/2000/svg';

  const projection = d3.geoEquirectangular().translate([VIEW.w / 2, VIEW.h / 2 + 12]).scale(158);
  const path = d3.geoPath(projection);
  const gMap = d3.select(svg).append('g').attr('class', 'map-root');

  svg.setAttribute('viewBox', `0 0 ${VIEW.w} ${VIEW.h}`);
  svg.setAttribute('preserveAspectRatio', 'xMidYMid slice');

  const layer = { grid: gMap.append('g'), land: gMap.append('g'), arcs: gMap.append('g'),
    pins: gMap.append('g'), ui: gMap.append('g') };

  layer.grid.append('path')
    .attr('class', 'graticule')
    .attr('d', path(d3.geoGraticule10()));

  // 手动锚点 → 经纬度换算（地图坐标 pin.x/pin.y 转地理坐标）
  // 说明：术语库要求"钉在世界地图上"。为让密集的国内节点各有落点，
  // 本页对 5 个中国节点同时给出地理坐标（lat/lon）与可视化锚点（pin），
  // 地图上的点位按地理坐标投影，图钉与弧线按锚点位置绘制。
  function pinProject(n) {
    const k = 1000 / svg.clientWidth;
    const pt = svg.createSVGPoint();
    pt.x = n.pin.x; pt.y = n.pin.y;
    const m = layer.pins.node().getScreenCTM().inverse();
    const p = pt.matrixTransform(m);
    return { x: p.x * k, y: p.y * k };
  }

  d3.json('topo.json').then(function (topology) {
    const countries = topojson.feature(topology, topology.objects.countries);

    layer.land.selectAll('path')
      .data(countries.features)
      .enter().append('path')
      .attr('class', 'land')
      .attr('d', path)
      .append('title')
      .text(d => d.properties.name);

    drawPins();
    document.getElementById('boot').style.display = 'none';
  }).catch(function (err) {
    document.getElementById('boot').innerHTML =
      '<div class="boot-inner"><p style="color:#ffb199">⚠️ 地图数据加载失败</p><small>请确认 topo.json 与本页位于同一目录，并通过本地服务器（而非 file://）打开。</small></div>';
    console.error(err);
  });

  function geoXY(n) { const p = projection([n.lon, n.lat]); return { x: p[0], y: p[1] }; }

  function drawPins() {
    // 从成都（成都校区）到各国际节点的示意弧线
    const arcs = [
      ['n1958', 'n2025'], ['n2002', 'n2025'], ['n2017', 'n2025']
    ];
    arcs.forEach(function (pair) {
      const a = NODES.find(n => n.id === pair[0]);
      const b = NODES.find(n => n.id === pair[1]);
      const pa = projection([a.lon, a.lat]), pb = projection([b.lon, b.lat]);
      const dx = pb[0] - pa[0], dy = pb[1] - pa[1];
      const mx = (pa[0] + pb[0]) / 2, my = (pa[1] + pb[1]) / 2 - Math.min(70, Math.hypot(dx, dy) * 0.18);
      const d = `M${pa[0]},${pa[1]} Q${mx},${my} ${pb[0]},${pb[1]}`;
      layer.arcs.append('path').attr('class', 'arc').attr('d', d);
    });

    const sel = layer.pins.selectAll('g.pin-g')
      .data(NODES, d => d.id)
      .enter().append('g')
      .attr('class', 'pin-g')
      .attr('transform', d => `translate(${d.pin.x},${d.pin.y})`);

    sel.each(function (d) {
      const g = d3.select(this);
      g.append('circle').attr('class', 'pin-ring').attr('r', 14);
      g.append('circle').attr('class', 'pin').attr('r', 7.2).attr('data-id', d.id)
        .append('title').text(d => `${d.yr} · ${d.cn}`);
      g.append('text').attr('class', 'pin-label').attr('y', 25).attr('text-anchor', 'middle').text(d => d.yr);
      g.append('text').attr('class', 'pin-label en').attr('y', 37).attr('text-anchor', 'middle')
        .text(d => d.countryEn.split(',')[0]);
    });

    renderLegend();
    renderCards();

    d3.select(svg).on('click', function (ev) {
      const t = ev.target.closest ? ev.target.closest('.pin-g') : null;
      if (!t) return;
      const id = t.querySelector('.pin').getAttribute('data-id');
      openDetail(id);
    });
  }

  /* ---------- 5. 缩放 ---------- */
  const zoom = d3.zoom().scaleExtent([1, 5]).on('zoom', e => {
    gMap.attr('transform', e.transform);
    gMap.attr('stroke-width', 1 / e.transform.k);
  });
  d3.select(svg).call(zoom).on('dblclick.zoom', null);
  document.getElementById('zoomIn').onclick = () => d3.select(svg).transition().call(zoom.scaleBy, 1.5);
  document.getElementById('zoomOut').onclick = () => d3.select(svg).transition().call(zoom.scaleBy, 1 / 1.5);
  document.getElementById('zoomReset').onclick = () => d3.select(svg).transition().call(zoom.transform, d3.zoomIdentity);

  /* ---------- 6. 卡片 ---------- */
  function renderCards() {
    const wrap = document.getElementById('cards');
    wrap.innerHTML = '';
    NODES.forEach(n => {
      const el = document.createElement('article');
      el.className = 'node'; el.dataset.cat = n.cat; el.dataset.id = n.id;
      el.innerHTML =
        `<div class="node-head"><span class="node-yr">${n.yr}</span><span class="node-coord">${n.lat.toFixed(2)}°N ${n.lon.toFixed(2)}°E</span></div>
         <h3>${n.cn}</h3>
         <p class="en">${n.en}</p>
         <p class="node-place"><span class="flag">${n.flag}</span>${n.country}</p>
         <p class="node-b">${n.cnLong.length > 92 ? n.cnLong.slice(0, 92) + '…' : n.cnLong}</p>
         <div class="node-foot"><span class="node-cat">${I18N[lang].cat[n.cat]}</span><span class="node-arrow">${I18N[lang].openCard}</span></div>`;
      el.onclick = () => openDetail(n.id);
      wrap.appendChild(el);
    });
  }

  /* ---------- 7. 图例 ---------- */
  function renderLegend() {
    const ol = document.getElementById('legendList');
    ol.innerHTML = '';
    NODES.forEach(n => {
      const li = document.createElement('li');
      li.dataset.id = n.id;
      li.innerHTML = `<b>${n.yr}</b> ${n.cn}<br><span style="color:#8b9aa8">${n.flag} ${n.countryEn}</span>`;
      li.onclick = () => openDetail(n.id);
      ol.appendChild(li);
    });
  }

  /* ---------- 8. 详情抽屉 ---------- */
  const detail = document.getElementById('detail');
  function openDetail(id) {
    const n = NODES.find(x => x.id === id);
    if (!n) return;
    document.getElementById('dFlag').textContent = n.flag;
    document.getElementById('dCoord').textContent = `${I18N[lang].place}　${n.lat.toFixed(4)}°N　${n.lon.toFixed(4)}°E`;
    document.getElementById('dTitle').textContent = n.cn;
    document.getElementById('dEn').textContent = n.en;
    document.getElementById('dBody').innerHTML =
      `<div class="zh">${renderZh(n)}</div>
       <div class="en-t">ENGLISH VERSION</div>
       <div class="en">${renderEn(n)}</div>`;
    document.getElementById('dTags').innerHTML = n.tags.map(t => `<i>${t}</i>`).join('');
    document.getElementById('dTerms').innerHTML = renderTerms(n);
    detail.hidden = false;
    document.body.style.overflow = 'hidden';
    syncActive(n.id);
  }
  function renderZh(n) {
    return n.cnLong.replace(/四川石油学院|西南石油学院|西南石油大学|川中石油会战|建校纪念日|博士学位授予权|全球首套|固态流化试采|天然气水合物|海洋天然气水合物|石油工程|院士|马载|罗平亚|周守为|中海油|中石油|伊拉克石油部|振华石油/g, m => `<b>${m}</b>`);
  }
  function renderEn(n) {
    return n.enLong.replace(/Sichuan Petroleum Institute|Southwest Petroleum Institute|Southwest Petroleum University \(SWPU\)|the Chuanzhong Oil Campaign|founding anniversary|the authority to confer doctoral degrees|the world's first set of|trial production through solid fluidization|natural gas hydrate|marine natural gas hydrate|Petroleum Engineering|academician|Ma Zai|Luo Pingya|Zhou Shouwei|CNOOC|CNPC|the Ministry of Oil of Iraq|ZhenHua Oil/g, m => `<b>${m}</b>`);
  }
  function renderTerms(n) {
    const list = n.terms.map(t => {
      const hit = GLOSS.find(g => g.cn === t);
      if (!hit) return `<li><span>${t}</span></li>`;
      return `<li><em>${hit.bad || ''}</em><b>${hit.en}</b></li>`;
    }).join('');
    return `<div class="terms"><h4>${I18N[lang].termsTitle}</h4><ul>${list}</ul></div>`;
  }
  function closeDetail() {
    detail.hidden = true;
    document.body.style.overflow = '';
    syncActive(null);
  }
  detail.querySelectorAll('[data-close]').forEach(el => el.onclick = closeDetail);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDetail(); });
  function syncActive(id) {
    document.querySelectorAll('.pin').forEach(p => p.dataset.active = (p.dataset.id === id) ? '1' : '0');
    document.querySelectorAll('#legendList li').forEach(li => li.classList.toggle('on', li.dataset.id === id));
  }

  /* ---------- 9. 术语库交互 ---------- */
  const gGrid = document.getElementById('gGrid');
  let gKw = '';
  function renderGloss() {
    const kw = gKw.trim().toLowerCase();
    const list = GLOSS.filter(g =>
      !kw || g.cn.toLowerCase().includes(kw) || g.en.toLowerCase().includes(kw));
    gGrid.innerHTML = list.map(g => {
      const bad = g.bad ? `<span class="g-bad">✕ ${g.bad}</span>` : '';
      const tag = g.tag ? `<span class="g-tag">${g.tag}</span>` : '';
      return `<div class="g" data-en="${g.en.replace(/"/g, '&quot;')}">${tag}
        <div class="g-cn">${g.cn}</div><div class="g-en">${g.en}</div>${bad}</div>`;
    }).join('');
    document.getElementById('gNote').hidden = list.length > 0;
    document.getElementById('gNote').textContent = I18N[lang].noResult;
    document.getElementById('gTag').textContent = `${I18N[lang].gAll.replace(/\d+/, '')} ${GLOSS.length}`;
  }
  gGrid.addEventListener('click', e => {
    const card = e.target.closest('.g'); if (!card) return;
    const en = card.dataset.en;
    copyText(en).then(() => toast(I18N[lang].copyOK)).catch(() => {});
    document.querySelectorAll('.g').forEach(c => c.classList.remove('on'));
    card.classList.add('on');
  });
  document.getElementById('gSearch').addEventListener('input', e => { gKw = e.target.value; renderGloss(); });
  document.getElementById('gTag').onclick = () => { gKw = ''; document.getElementById('gSearch').value = ''; renderGloss(); };

  function copyText(s) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(s);
    return new Promise((res, rej) => {
      const t = document.createElement('textarea');
      t.value = s; t.style.position = 'fixed'; t.style.opacity = '0';
      document.body.appendChild(t); t.select();
      try { document.execCommand('copy'); res(); } catch (e) { rej(e); }
      document.body.removeChild(t);
    });
  }
  let toastTimer;
  function toast(msg) {
    let el = document.getElementById('toast');
    if (!el) { el = document.createElement('div'); el.id = 'toast';
      el.style.cssText = 'position:fixed;left:50%;bottom:34px;transform:translateX(-50%) translateY(20px);background:#0b1f33;color:#fff;padding:10px 20px;border-radius:999px;font-size:14px;z-index:80;opacity:0;transition:.25s;pointer-events:none';
      document.body.appendChild(el); }
    el.textContent = msg;
    requestAnimationFrame(() => { el.style.opacity = '1'; el.style.transform = 'translateX(-50%) translateY(0)'; });
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(-50%) translateY(20px)'; }, 1600);
  }

  /* ---------- 10. 语言切换 ---------- */
  const langBtn = document.getElementById('langSwitch');
  langBtn.onclick = () => {
    lang = lang === 'zh' ? 'en' : 'zh';
    document.documentElement.lang = lang === 'zh' ? 'zh-CN' : 'en';
    langBtn.classList.toggle('on', lang === 'en');
    langBtn.querySelector('.t').textContent = lang === 'zh' ? '中文' : 'English';
    document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = I18N[lang][el.dataset.i18n]; });
    document.getElementById('heroHint').textContent = lang === 'zh'
      ? '👆 点击地图上的任意一枚图钉查看双语卡片'
      : '👆 Tap any pin on the map to open its bilingual card';
    renderCards();
    renderGloss();
  };

  // 初始化
  renderGloss();
})();
